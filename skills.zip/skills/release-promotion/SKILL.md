---
name: release-promotion
description: קידום גרסה בסדר develop -> staging -> main עם בדיקות, tag ו-rollback.
---
# Release Promotion

1. ודא `develop` ירוק ובדיקות מלאות עברו (`run-full-test-suite`).
2. פתח PR `develop -> staging`. המתן ל-checks ירוקים -> merge -> deploy אוטומטי ל-Staging.
3. ב-staging: smoke + UAT + בדיקות לא-פונקציונליות מלאות. שמור דוח.
4. רק אם הכל ירוק: PR `staging -> main` (אישור מפורש של המשתמש - production).
5. אחרי merge: וידוא deploy, smoke ב-production, צפייה במדדים 30 דקות.
6. Tag SemVer + CHANGELOG + GitHub Release.
7. כשל בכל שלב: rollback לגרסה קודמת ב-Railway, פתח incident (`incident-response`). לעולם לא מדלגים על staging.
