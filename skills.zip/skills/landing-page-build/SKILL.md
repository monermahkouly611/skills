---
name: landing-page-build
description: בניית דף נחיתה ממיר עם מיתוג, שיווק, SEO ומדידה.
---
# Landing Page Build

1. בריף: מוצר, קהל, הצעת ערך, יעד המרה, ערוץ תנועה (גוגל/רשתות).
2. מבנה: Hero+CTA, בעיה, פתרון, יתרונות, הוכחה חברתית אמיתית, תהליך, התנגדויות/FAQ, CTA סופי, פוטר עם פרטיות/תקנון.
3. מיתוג בדף: לוגו, פלטה, טון, מסרים. עיצוב דרך `design-from-stitch`.
4. SEO: metadata, JSON-LD, sitemap, canonical, מהירות. פיקסלים + אירועי המרה אחרי הסכמה.
5. טופס: ולידציה, אנטי-ספאם (honeypot/Turnstile), UTM נשמרים, opt-in, שמירה ב-DB, התראה/WhatsApp.
6. A/B testing, בדיקות מלאות, Lighthouse >= 90.
7. קישור למאמרי תמיכה (`seo-article-factory`).
