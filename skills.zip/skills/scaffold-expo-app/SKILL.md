---
name: scaffold-expo-app
description: יצירת שלד אפליקציית Expo עם EAS Build ל-Android ו-iOS ושרת Node/Python.
---
# Scaffold Expo App

1. `dependency-vulnerability-scan` ל-Expo SDK ותלויות.
2. `create-expo-app` (TS strict, Expo Router), ESLint, Jest/RNTL, Maestro.
3. `eas.json` עם development / staging(preview) / production; channels ל-EAS Update; `appVersionSource: remote`.
4. הגדרת bundle id / package name, אייקונים, splash, הרשאות מינימליות, SecureStore, Sentry, i18n/RTL.
5. שרת: Node (Fastify/NestJS) או Python (FastAPI) לפי ADR; OpenAPI; auth; `/healthz`.
6. CI: בנייה ב-EAS מ-GitHub Actions - preview מ-staging, production רק מ-main.
7. רשימת חנויות: מדיניות פרטיות, Data Safety/App Privacy, מחיקת חשבון באפליקציה.
8. עיצוב: `design-from-stitch` אחרי שהשלד מוכן.
