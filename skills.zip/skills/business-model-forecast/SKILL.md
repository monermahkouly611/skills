---
name: business-model-forecast
description: בניית מודל עסקי נוכחי ותחזית עתידית.
---
# Business Model & Forecast

1. Business Model Canvas למצב הווה.
2. מודל פיננסי (Sheets/xlsx): הכנסות, עלויות (Railway, LLM, שיווק, כוח אדם), unit economics.
3. תחזית 3-5 שנים, 3 תרחישים (בסיס/אופטימי/פסימי), ניתוח רגישות.
4. כל הנחה מתועדת ומקורה. נתוני שוק עם ציטוט.
5. שמור ב-`docs/business/`.
