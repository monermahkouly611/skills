---
name: whatsapp-meta-integration
description: חיבור סוכן WhatsApp רשמי דרך Meta Cloud API - שירות, לידים, חימום, שיוך.
---
# WhatsApp via Meta

דרישות מהמשתמש: Meta Business Manager מאומת, מספר, אפליקציית Meta, הרשאות. אל תמציא מפתחות.
1. הגדר WhatsApp Cloud API: access token (system user), phone number id, webhook verify token. הכל ב-Secrets.
2. Endpoint webhook: אימות חתימה, ack מהיר, תור Redis, idempotency.
3. חיבור ל-`agent-service` (`ai-support-agent-setup`) + הסלמה לנציג.
4. מודל לידים: `lead(id, phone, name, source, group, campaign, status, score, consent, timestamps)`; שיוך לפי UTM/click-to-WhatsApp/QR.
5. Templates: ליצירת חימום ולמסרים מחוץ ל-24 שעות; שליחה לאישור Meta. רצפי nurture עם הגבלת תדירות ו-opt-out.
6. בדיקות ב-sandbox. ניטור משלוחים ושגיאות.
7. עמידה במדיניות Meta ובסעיף 30א (opt-in).
