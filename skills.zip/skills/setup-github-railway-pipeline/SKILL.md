---
name: setup-github-railway-pipeline
description: הקמת pipeline ב-GitHub Actions ופריסה אוטומטית ל-Railway לפי ענפים develop/staging/main.
---
# GitHub -> Railway Pipeline

1. ב-Railway: Project עם Environments `development`, `staging`, `production`. חבר כל Environment לריפו ב-GitHub וקשור לענף: develop / staging / main. הפעל "Wait for CI" כך שה-deploy ממתין ל-checks ירוקים.
2. העתק מ-`templates/github-workflows/`: `ci-light.yml` (PR לפני develop), `ci-full.yml` (PR ל-develop/staging/main), `promote.yml` (פותח PR קידום).
3. הגדר Secrets ב-GitHub ו-Variables ב-Railway לכל סביבה בנפרד.
4. Required status checks: lint, typecheck, unit, build, security, ובמלאות גם e2e/perf/a11y. הרץ `templates/branch-protection.sh`.
5. Pre-deploy: migrations. Post-deploy: smoke tests + rollback במקרה כשל.
6. אימות: PR בדיקה ל-develop -> ודא deploy ל-Development בלבד; קידום -> staging; קידום -> main.
7. תעד ב-`docs/runbook.md` איך מבצעים rollback.
