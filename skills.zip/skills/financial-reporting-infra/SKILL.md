---
name: financial-reporting-infra
description: הכנת תשתית לדוחות רבעוניים ושנתיים.
---
# Financial Reporting Infra

1. הגדר KPI: MRR/ARR, צמיחה, churn, CAC, LTV, burn, runway, margin.
2. מקורות נתונים: DB, תשלומים, שיווק; שאילתות/views ב-PostgreSQL לכל מדד.
3. תבניות: דוח רבעוני ושנתי (`docs/business/reports/`), כולל השוואה לתחזית.
4. אוטומציה: job מתוזמן שמפיק נתונים; דשבורד.
5. סימון: אין תחליף לרואה חשבון. דוחות סטטוטוריים נבדקים מקצועית.
