---
name: scaffold-nextjs-project
description: יצירת שלד Next.js + PostgreSQL לאתר ומערכת ניהול באותו פרויקט עם הפרדת תיקיות.
---
# Scaffold Next.js

1. `dependency-vulnerability-scan` לגרסאות Next/Node/Postgres.
2. צור Next.js (App Router, TS strict), ESLint, Prettier, Vitest, Playwright, husky.
3. מבנה: `src/app/(site)`, `src/app/(admin)`, `src/modules`, `src/lib`, `src/db`, `src/ui` (ראה `08-stack-web-nextjs.md`).
4. תשתית משותפת פעם אחת: auth + RBAC (admin מוגן, noindex), i18n/RTL, design tokens, SEO helpers (metadata, sitemap, robots), error handling, logging, env validation.
5. DB: Prisma/Drizzle + migration ראשון, Docker Compose מקומי ל-Postgres/Redis, seed סינתטי.
6. `/healthz`, `/readyz`. Dockerfile/Nixpacks לפריסה ב-Railway.
7. הרץ build + בדיקות קלות; commit ל-`develop`.
8. עיצוב נכנס רק עכשיו: `design-from-stitch`.
