---
name: project-kickoff
description: פתיחת פרויקט חדש מאפס - ריפו, ענפים, CI, Railway, מסמכים. להפעלה בתחילת כל פרויקט.
---
# Project Kickoff

1. **בריף:** שאל (בהודעה אחת): שם, סוג (אפליקציה/אתר+אדמין/דף נחיתה), שוק יעד ושפות, ספק AI (Claude/OpenAI), האם WhatsApp נדרש. אל תתחיל לפני סוג ברור.
2. **ריפו:** `git init`, README, `.gitignore`, `.env.example`, LICENSE, `docs/` (ADR, runbook, business, marketing), `CODEOWNERS`, PR template, issue templates.
3. **ענפים:** צור `develop`, `staging`, `main` בענן; מקומית רק `develop` (`git checkout develop`). ראה `01-git-branching-workflow.md`.
4. **Branch protection** ל-3 הענפים: הרץ `templates/branch-protection.sh` (נדרש `gh`).
5. **CI:** העתק workflows מ-`templates/github-workflows/` והתאם. skill `setup-github-railway-pipeline`.
6. **שלד** לפי הסוג: `scaffold-nextjs-project` או `scaffold-expo-app`.
7. **סריקת תלויות** לפני נעילת גרסאות: `dependency-vulnerability-scan`.
8. **Railway:** 3 סביבות + שירותים (אתר, נחיתה, API, Postgres, Redis, סוכן).
9. **ADR ראשון:** תיעוד בחירות סטאק. Definition of Done ב-README.
10. דווח למשתמש מה הוקם ומה נדרש ממנו (הרשאות, מפתחות).
