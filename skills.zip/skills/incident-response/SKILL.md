---
name: incident-response
description: תגובה לתקלה או פרצה ב-production - rollback, תקשורת, postmortem.
---
# Incident Response

1. זהה חומרה (SEV1-3) ואמת.
2. **עצור נזק:** rollback ב-Railway לגרסה קודמת, או feature flag off.
3. פרצת אבטחה: רוטציית סודות, ניתוק חשבונות, שמירת לוגים; בחינת חובת דיווח (חוק הפרטיות/GDPR - 72 שעות).
4. עדכן את המשתמש. 5. תיקון דרך הרצף המלא (בדיקה שנכשלת -> fix -> develop -> staging -> main).
6. Postmortem ללא האשמה: ציר זמן, שורש, פעולות מניעה; עדכון בדיקות/אלרטים/runbook.
