---
name: ai-support-agent-setup
description: הקמת סוכן AI שירות לקוחות עם שירות שרת שניתן להרחבה לסוכנים נוספים, על Claude או OpenAI.
---
# AI Support Agent

1. שאל: ספק (Claude/OpenAI), ערוצים, בסיס ידע, מדיניות הסלמה.
2. שירות `agent-service` (Node/Python) ב-Railway: provider interface, agent registry, tools registry, memory (Redis/Postgres), queue.
3. סוכן שירות לקוחות ראשון: system prompt, כלים בהרשאות מינימליות, RAG (pgvector) עם ציטוט, הסלמה לנציג.
4. אבטחה: מפתחות בשרת, הגנה מ-injection, אישור אנושי לפעולות רגישות, rate limit ותקציב טוקנים.
5. Evals: סט שאלות זהב + בדיקות בטיחות ב-CI. לוגים עם מיסוך PII.
6. הצהרת "אתה מדבר עם AI" וקישור לנציג. תיעוד איך מוסיפים סוכן חדש.
