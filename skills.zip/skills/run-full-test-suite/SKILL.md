---
name: run-full-test-suite
description: הרצת בדיקות מלאות (e2e, ביצועים, אבטחה, נגישות ועוד) לפני קידום מ-develop הלאה.
---
# Full Test Suite

הרץ ודווח בטבלה (עבר/נכשל/דולג + סיבה). ראה `03-testing-standards.md`.
1. Lint, typecheck, unit, integration, contract.
2. E2E: Playwright (ווב) / Maestro (אפליקציה) על תרחישים מרכזיים.
3. Regression + smoke; migrations קדימה ואחורה.
4. ביצועים: k6 load/stress/soak + Lighthouse (CWV).
5. אבטחה: CodeQL/Semgrep, ZAP baseline, `dependency-vulnerability-scan`, gitleaks, Trivy.
6. נגישות: axe. תאימות דפדפנים/מכשירים. i18n/RTL.
7. Backup/restore + rollback drill ב-staging.
כשל = עצור את הקידום, צור issue עם repro. אל תסמן "ירוק" בלי ריצה אמיתית.
